
#include "expand.h"
#include <bitset>
#include <random>
#include <iostream>

using namespace std;


#define ORI 0
#define INV 1

#define SBOX_TYPE INV


#if SBOX_TYPE == ORI

const type_t t[9]{
        0b1010, //t41
        0b0101, //t42
        0b0011, //t43
        0b1100, //t44
        0b1111, //t45
        0b0001, //t21
        0b0010, //t22
        0b0100, //t23
        0b1000  //t24
};


const vector<expression_t2> impl_B{
        {1,  s6, t[3], y[15]},
        {2,  s1, t[8], y[6]},
        {3,  s0, t[2], y[16]},
        {4,  s4, t[6], y[1]},
        {5,  s3, t[3], y[12]},
        {6,  s5, t[8], y[3]},
        {7,  s2, t[2], y[13]},
        {8,  s7, t[6], y[5]},
        {11, s2, t[1], y[9]},
        {12, s0, t[1], y[11]},
        {13, s5, t[4], y[14]},
        {14, s0, t[4], y[17]},
        {17, s2, t[5], y[2]},
        {19, s6, t[7], y[0]},
        {21, s4, t[5], y[7]},
        {22, s5, t[7], y[4]},
        {23, s3, t[1], y[9]},
        {24, s6, t[4], y[17]},
        {25, s6, t[0], y[10]},
        {26, s7, t[4], y[14]},
        {33, s2, t[0], y[8]}
};


const vector<barrier> barrier_B{
        {9,  s4},
        {10, s0},
        {15, s2},
        {16, s6},
        {18, s5},
        {20, s6},
        {27, s6},
        {28, s2},
        {29, s0},
        {30, s3},
        {31, s1},
        {32, s4}
};

#elif SBOX_TYPE == INV
const type_t t[9]{
        0b1100, //t41
        0b1010, //t42
        0b0101, //t43
        0b1111, //t44
        0b0011, //t45
        0b0001, //t21
        0b0010, //t22
        0b0100, //t23
        0b1000  //t24
};


const vector<expression_t2> impl_B{
        {1,  s0, t[1], y[14]},
        {2,  s6, t[3], y[10]},
        {3,  s3, t[4], y[8]},
        {4,  s5, t[5], y[0]},
        {5,  s1, t[1], y[15]},
        {6,  s2, t[3], y[11]},
        {7,  s4, t[4], y[9]},
        {8,  s7, t[5], y[4]},
        {9,  s2, t[2], y[13]},
        {10, s3, t[0], y[16]},
        {11, s6, t[7], y[2]},
        {12, s0, t[0], y[16]},
        {13, s7, t[6], y[5]},
        {14, s4, t[6], y[5]},
        {18, s3, t[6], y[1]},
        {20, s2, t[7], y[6]},
        {21, s1, t[2], y[13]},
        {23, s2, t[8], y[7]},
        {25, s4, t[0], y[17]},
        {27, s6, t[2], y[12]},
        {29, s2, t[8], y[3]},
        {30, s6, t[8], y[3]},
        {31, s4, t[8], y[7]},
        {32, s5, t[7], y[2]}
};


const vector<barrier> barrier_B{
        {15, s6},
        {16, s0},
        {17, s3},
        {19, s2},
        {22, s4},
        {24, s2},
        {26, s3},
        {28, s6}

};
#endif

bool operator==(const expression_t2 &t1, const expression_t2 &t2) {
    return t1.index == t2.index;
}

inline bool in_C(vector<par_C2> &C, expression_t2 &exp) {
    for (auto c: C) {
        auto res = find(begin(c), end(c), exp);
        if (res == end(c))
            continue;
        else return true;
    }
    return false;
}

inline bool can_move(const par_C2 &C, const expression_t2 &exp) {
    int s = C[0].index;
    int e = exp.index;
    for (auto b: barrier_B) {
        if (s < e) {
            if (b.index > s && b.index < e) {
                if (exp.t == b.t) {
                    return false;
                }
            }
        } else {
            if (b.index > e && b.index < s) {
                if (exp.t == b.t) {
                    return false;
                }
            }
        }
    }
    return true;
}

inline bool is_no_shares_t(const par_C2 &C, const expression_t2 &exp) {
    for (auto e: C) {
        if (e.t == exp.t) return false;
    }
    return true;
}


inline bool is_not_share_middle_right(const par_C2 &C, const expression_t2 &exp) {
    for (auto e: C) {
        if (e.middle == exp.middle || e.right == exp.right)
            return false;
    }
    return true;
}

inline bool is_independent(const par_C2 &C, const expression_t2 &exp) {
    vector<bitset<8>> list;
    for (auto e: C) {
        list.push_back(e.right);
    }
    list.push_back(exp.right);
    int n = list.size();
    int doing = 0;
    for (int i = 7; i >= 0; --i) {
        if (list[doing][i] != 1) {
            bool find = false;
            for (int j = doing + 1; j < n; ++j) {
                if (list[j][i] == 1) {
                    swap(list[doing], list[j]);
                    find = true;
                    break;
                }
            }
            if (!find)
                continue;
        }
        for (int j = doing + 1; j < n; ++j) {
            if (list[j][i] == 1) {
                list[j] ^= list[doing];
            }
        }
        doing++;
    }
    for (auto b: list) {
        if (b.none()) return false;
    }


    return true;
}


inline bool is_independent2(const par_C2 &C, const expression_t2 &exp) {
    vector<bitset<4>> list;
    for (auto e: C) {
        list.push_back(e.middle);
    }
    list.push_back(exp.middle);
    int n = list.size();
    int doing = 0;
    for (int i = 3; i >= 0; --i) {
        if (list[doing][i] != 1) {
            bool find = false;
            for (int j = doing + 1; j < n; ++j) {
                if (list[j][i] == 1) {
                    swap(list[doing], list[j]);
                    find = true;
                    break;
                }
            }
            if (!find)
                continue;
        }
        for (int j = doing + 1; j < n; ++j)
            if (list[j][i] == 1)
                list[j] ^= list[doing];

        doing++;
    }
    for (auto b: list) {
        if (b.none()) {
            return false;
        }
    }
    return true;

}

inline bool is_C_not_full(par_C2 &C) {
    if (C.size() <= 3) return true;
    else return false;
}

bool can_add_to_C(par_C2 &C, expression_t2 &exp) {
    return can_move(C, exp) && is_no_shares_t(C, exp) && is_not_share_middle_right(C, exp) && is_independent(C, exp) &&
           is_C_not_full(C)
           && is_independent2(C, exp);
}


void print_impl(const vector<par_C2> &C) {
    for (const auto &c: C) {
        for (auto e: c) {
            cout << e.index << " " << e.middle << " " << e.right << endl;
        }
        cout << endl;
    }
}

int get_C_exp_number(vector<par_C2> &C) {
    int num = 0;
    for (auto cs: C) {
        num += cs.size();
    }
    return num;
}

int optimize_B() {
    srand(time(NULL));
    default_random_engine randomEngine;
    vector<par_C2> C;
#if SBOX_TYPE == ORI
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[2]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[13]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[17]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[20]);
#elif SBOX_TYPE == INV
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[5]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[8]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[15]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[17]);
    C.emplace_back();
    C[C.size() - 1].push_back(impl_B[20]);
#endif

    while (get_C_exp_number(C) < impl_B.size()) {
        int index = rand() % impl_B.size();
        expression_t2 exp = impl_B[index];
        if (in_C(C, exp)) continue;

        vector<int> can_add;
        for (int i = 0; i < C.size(); ++i)
            if (can_add_to_C(C[i], exp))
                can_add.push_back(i);
        if (can_add.empty()) {
            C.emplace_back();
            C[C.size() - 1].push_back(exp);
        } else {
            int r = randomEngine() % can_add.size();
            C[can_add[r]].push_back(exp);
        }
    }
    if (C.size() <= 7) {
        cout << "C size: " << C.size() << endl;
        print_impl(C);
    }
    return C.size();
}