#include <iostream>
#include "expand.h"


int main() {
    while(optimize_U() > 3) continue;
    while(optimize_B() > 7) continue;
    execute_expand();
    return 0;
}
